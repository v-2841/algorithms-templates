# 87162099
from typing import List


def distances_to_0(arrow: List[int]) -> List[int]:
    result = [None] * len(arrow)
    count = 0
    for id, val in enumerate(arrow):
        if val == 0:
            result[id] = 0
            count = 1
        elif count != 0:
            result[id] = count
            count += 1
    for id, val in reversed(list(enumerate(arrow))):
        if val == 0:
            count = 1
        elif result[id] is None:
            result[id] = count
            count += 1
        elif count < result[id]:
            result[id] = count
            count += 1
    return result


def read_input() -> List[int]:
    _ = input()
    return [int(num) for num in input().split()]


if __name__ == '__main__':
    print(*distances_to_0(read_input()), sep=' ', end='')
